// pages/upload.js
var util = require('../../utils/util.js')
var app = getApp()
Page({
  

  /**
   * 页面的初始数据
   */
  data: {
   // multiArray: [['竹园', '海棠', '丁香'], ['1楼', '2楼', '3楼']],
   // multiIndex: [0, 0],
   // maxlength: 200,
    imageList: [],
    array: ['微辣', '麻辣', '酸甜', '红烧', '清淡', '原汁原味','浓油赤酱','醇厚鲜美'],
    index: 0,
    countIndex: 1,
   // imgUrl: "/public/images/3.jpg"
    tempFilePath: '',
    savedFilePath: '',
    dialog: {
      hidden: true
    },
    imgList: ['1.jpg','2.jpg','3.jpg','4.jpg','5.jpg']
  },

  bindPickerChange: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      index: e.detail.value
    })
  },

  formSubmit: function (e) {
    var that = this
    console.log('form发生了submit事件，携带数据为', e.detail.value)
    var k = 0
    k = Math.floor(Math.random()*5)
    if (e.detail.value.dname == '' || e.detail.value.dprice == '') {
      wx.showModal({
        title: "友情提示",
        content: "有内容为空哦！",
        showCancel: false,
        confirmText: "确定"
      })
    } else{
        wx.request({
          url: 'https://www.iwbagm.cn/xcx/upload.php',
          data: { 
            dname: e.detail.value.dname,
            dprice: e.detail.value.dprice,
            dstyle: e.detail.value.dstyle,
            dpic: that.data.imgList[k],
            },
          method: 'GET', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
          header: { 'Content-Type': 'application/json' }, // 设置请求的 header
          success: function (res) {
            console.log(res.data)
            util.showSuccess('上传成功')
            setTimeout(function(){
              wx.navigateBack({
              delta: 1
              })
            }, 1000)
          }
        })
    }
  },

  formReset: function () {
    console.log('form发生了reset事件')
    this.setData ({
      savedFilePath: ''
    })
    try {
      var value = wx.getStorageSync('savedFilePath')
      this.setData({
        savedFilePath: value
      })
      if (value) {
        // Do something with return value
      }
    } catch (e) {
      // Do something when catch error
    }
  },

  // 上传图片接口
  chooseImage: function () {
    var that = this
    wx.chooseImage({
      sourceType: ['camera', 'album'],
      sizeType: ['compressed'],
      count: 1,
      success: function (res) {
        util.showBusy('正在上传')
        console.log(res)
        that.setData({
          imageList: res.tempFilePaths,
          tempFilePath: res.tempFilePaths[0]
        })
        var tempFilePaths = res.tempFilePaths
        wx.saveFile({
          tempFilePath: tempFilePaths[0],
          success: function (res) {
            that.setData({
              savedFilePath: res.savedFilePath
            })
            wx.setStorageSync('savedFilePath', res.savedFilePath)
            that.setData({
              dialog: {
                title: '保存成功',
                content: '下次进入应用时，此文件仍可用',
                hidden: false
              }
            })
          },
          fail: function (res) {
            that.setData({
              dialog: {
                title: '保存失败',
                content: '应该是有 bug 吧',
                hidden: false
              }
            })
          }
        })
        // wx.uploadFile({
        //   url: 'https://www.iwbagm.cn/xcx/test.php',
        //   filePath: tempFilePaths[0],
        //   header: { "Content-Type": "multipart/form-data" },
        //   name: 'file',
        //   success: function (res) {
        //     //打印
        //     console.log(res.data)
        //   }
        // })
      }
    })
  },

  // 预览图片
  previewImage: function (e) {
    var current = e.target.dataset.src
    console.log(1)
    wx.previewImage({
      current: current,
      urls: this.data.imageList
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
   console.log(app.openid)
   this.setData({
     savedFilePath: wx.getStorageSync('savedFilePath')
   })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.setData({ msg: "Hello World" })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },
})