
// pages/count/count.js
Page({
  data: {
    width: 0,
    height: 0,
    cnt: 3,
    color: ['#9ac0cd',  '#ffb09d', '#8cea00', '#ffe66f', '#ff77ff', '#ff7575', '#adadad'],
    index: 0,
    time: 4,
  },
  onLoad: function (options) {

    this.setData({
      index: Math.floor(Math.random() * 7)
    })
    var that = this
    //获取系统信息 
    wx.getSystemInfo({
      //获取系统信息成功，将系统窗口的宽高赋给页面的宽高  
      success: function (res) {
        that.data.width = res.windowWidth
        // console.log(that.width)   375
        that.data.height = res.windowHeight
        // console.log(that.height)  625
        // 这里的单位是PX，实际的手机屏幕有一个Dpr，这里选择iphone，默认Dpr是2
      }
    })
    wx.request({
      url: 'https://www.iwbagm.cn/xcx/count.php/',
      data: {},
      method: 'GET', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
      header: { 'Content-Type': 'application/json' }, // 设置请求的 header
      success: function (res) {
        console.log(res.data)
        var tmp
        if (res.data < 10)
          tmp = '0' + res.data
        else 
          tmp = res.data
        that.setData({
          cnt: tmp,
          time: 4 + res.data - 5
        })
        // 使用 wx.createContext 获取绘图上下文 context
        var context = wx.createCanvasContext('firstCanvas')
        console.log(that.data.height)
        var height = that.data.height;
        var width = that.data.width;
        // 设置文字对应的半径
        var R = width / 2 - 60;
        // 把原点的位置移动到屏幕中间，及宽的一半，高的一半
        context.translate(width / 2, height / 2 - 50);
        context.setStrokeStyle("#eee");//#aeeeee
        context.setLineWidth(8);
        context.beginPath();
        // 运动一个圆的路径
        // arc(x,y,半径,起始位置，结束位置，false为顺时针运动)
        context.arc(0, 0, width / 2 - 40, 0, 2 * Math.PI, false);
        context.closePath();
        // 描出点的路径
        context.stroke();
        context.font = "160rpx Verdana";
        context.fillStyle = "#eee";
        context.fillText(that.data.cnt, -100, 55);
        context.draw()
      }
    })

   
  },

  onReady: function (e) {
    
  }
})