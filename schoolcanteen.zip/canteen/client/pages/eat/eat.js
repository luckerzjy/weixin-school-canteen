Page({
  data: {
    navs: [
      { navimg: '/public/images/l1.png' },
      { navimg: '/public/images/l3.png' },
    ],
    address: {},
    array: ['海棠', '竹园', '丁香'],
    index: 0,
    hasAddress: false,

    all: [
      {
        id: "001",
        imgUrl: "/public/images/big.jpg",
        name: "大碗饭",
        intro: "主打家常菜，分量大，价格实惠"
      },
      {
        id: "002",
        imgUrl: "/public/images/lp.jpg",
        name: "魏家凉皮",
        intro: "凉皮，饺子，面条有售"
      },
      {
        id: "003",
        imgUrl: "/public/images/3.jpg",
        name: "黄焖鸡米饭",
        intro: "主打黄焖鸡米饭，另有 各类盒饭"
      },
      {
        id: "004",
        imgUrl: "/public/images/s.jpg",
        name: "少掌柜",
        intro: "各类小炒，可自行选配食材"
      },
      {
        id: "005",
        imgUrl: "/public/images/w.jpg",
        name: "真味坊",
        intro: "口味清淡，各类蒸的食品"
      },
      {
        id: "006",
        imgUrl: "/public/images/r.jpg",
        name: "北海道",
        intro: "主打各类日式菜品"
      },
      {
        id: "007",
        imgUrl: "/public/images/l.jpg",
        name: "邻家美食",
        intro: "妈妈的味道，家常炒菜"
      },
      {
        id: "008",
        imgUrl: "/public/images/j.jpg",
        name: "金牌小菜",
        intro: "主打各类小菜"
      },
      {
        id: "009",
        imgUrl: "/public/images/c.jpg",
        name: "川乐",
        intro: "主打四川口味饭菜"
      },



    ],
    shop: [],


  },
  select: function (e) {
    this.setData({
      index: e.detail.value
    })


  },

  onLoad: function () {
    var that = this
    for (var i = 0; i < 3; i++) {
      var id = 'shop[' + i + '].id'
      console.log(id)
      var name = 'shop[' + i + '].name'
      var imgUrl = 'shop[' + i + '].imgUrl'
      var intro = 'shop[' + i + '].intro'
      that.setData({
        [id]: that.data.all[i].id,
        [name]: that.data.all[i].name,
        [imgUrl]: that.data.all[i].imgUrl,
        [intro]: that.data.all[i].intro,
      })
    }
  },


  bindPickerChange: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      index: e.detail.value
    })

    if (e.detail.value == 0) {
      var that = this
      for (var i = 0; i < 3; i++) {
        var id = 'shop[' + i + '].id'
        var name = 'shop[' + i + '].name'
        var imgUrl = 'shop[' + i + '].imgUrl'
        var intro = 'shop[' + i + '].intro'
        that.setData({
          [id]: that.data.all[i].id,
          [name]: that.data.all[i].name,
          [imgUrl]: that.data.all[i].imgUrl,
          [intro]: that.data.all[i].intro,
        })
      }
    }
    else if (e.detail.value == 1) {
      console.log('???')
      var that = this
      for (var i = 3; i < 6; i++) {
        var j = i - 3
        var id = 'shop[' + j + '].id'
        var name = 'shop[' + j + '].name'
        var imgUrl = 'shop[' + j + '].imgUrl'
        var intro = 'shop[' + j + '].intro'
        that.setData({
          [id]: that.data.all[i].id,
          [name]: that.data.all[i].name,
          [imgUrl]: that.data.all[i].imgUrl,
          [intro]: that.data.all[i].intro,
        })
      }
    }
    else if (e.detail.value == 2) {
      console.log('???')
      var that = this
      for (var i = 6; i < 9; i++) {
        var j = i - 6
        var id = 'shop[' + j + '].id'
        var name = 'shop[' + j + '].name'
        var imgUrl = 'shop[' + j + '].imgUrl'
        var intro = 'shop[' + j + '].intro'
        that.setData({
          [id]: that.data.all[i].id,
          [name]: that.data.all[i].name,
          [imgUrl]: that.data.all[i].imgUrl,
          [intro]: that.data.all[i].intro,
        })
      }
    }



  },

  to1: function (e) {
    console.log(e.currentTarget.dataset)
    var outid = e.currentTarget.dataset.id
    wx.setStorage({
      key: "nowid",
      data: outid
    })
    wx.setStorage({
      key: "nowname",
      data: e.currentTarget.dataset.name
    })
    wx.navigateTo({
      url: '../detail/detail',
    })
  },
});
