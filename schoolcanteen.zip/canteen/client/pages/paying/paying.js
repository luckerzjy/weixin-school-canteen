Page({
  data: {
    address: {},
    array: ['海棠：7:00', '海棠：8:00', '竹园:11:00', '丁香：13:00', '丁香：17:00'],
    price: 0,
    index: 0,
    hasAddress: false,
  },
  select: function (e) {
    this.setData({
      index: e.detail.value
    })
  },
  onShow: function () {
    var _this = this
    wx.getStorage({
      key: 'money',
      success(res) {
        console.log(res.data)
        _this.setData({
          price: res.data,
        })
      }
    })


  },

  pay: function (e) {
    wx.showModal({
      title: '支付提示',
      content: '本程序仅用于演示，支付接口API已屏蔽！',
      showCancel: false,
      success: function (res) {
        if (res.confirm) {
          console.log('用户点击确定')
        }
      }
    })

  }
});