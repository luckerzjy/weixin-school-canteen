//index.js
Page({

  toast1: function () {
    wx.navigateTo({
      url: '../eat/eat'
    })
    wx.setStorage({
      key: "choice",
      data: "in"
    })
    wx.setStorage({
      key: "cout",
      data: 0
    }),
    wx.setStorage({
      key: "money",
      data: 0
    })
    wx.setStorageSync('cart', [])
  },
   toast2: function () {
    wx.navigateTo({
      url: '../eat/eat'
    })
    wx.setStorage({
      key: "choice",
      data: "out"
    })
    wx.setStorage({
      key: "cout",
      data: 0
    })
    wx.setStorage({
      key: "money",
      data: 0
    })
    wx.setStorageSync('cart', [])
  }
})