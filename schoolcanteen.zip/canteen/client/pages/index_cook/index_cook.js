//index.js
var util = require('../../utils/util.js')
Page({
    data: {
      inputShowed: false,
      inputVal: "",
      num: [1,2,3,4,5,6,7,8,9,10,11,12,13,143,15],
      data: [
          {
            "id": 1,
            "state": "1",
            "lname": "牛排套餐",
            "lprice": "30.00",
            "lcontent": ""
          },
          {
            "id": 2,
            "state": "0",
            "lname": "牛排套餐",
            "lprice": "30.00",
            "lcontent": ""
          },
          {
            "id": 3,
            "state": "0",
            "lname": "牛排套餐",
            "lprice": "30.00",
            "lcontent": ""
          },
          {
            "id": 4,
            "state": "0",
            "lname": "牛排套餐",
            "lprice": "30.00",
            "lcontent": ""
          },
          {
            "id": 5,
            "state": "0",
            "lname": "牛排套餐",
            "lprice": "30.00",
            "lcontent": ""
          },
          {
            "id": 6,
            "state": "0",
            "lname": "牛排套餐",
            "lprice": "30.00",
            "lcontent": ""
          },
          {
            "id": 12                                     ,
            "state": "0",
            "lname": "牛排套餐",
            "lprice": "30.00",
            "lcontent": ""
          },
          {
            "id": 13,
            "state": "0",
            "lname": "牛排套餐",
            "lprice": "30.00",
            "lcontent": ""
          },
          {
            "id": 143,
            "state": "0",
            "lname": "牛排套餐",
            "lprice": "30.00",
            "lcontent": ""
          },
        ]
  
    },

    onPullDownRefresh: function () {
      var that = this
      wx.request({
        url: 'https://www.iwbagm.cn/xcx/list.php',
        data: {},
        method: 'GET', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
        header: { 'Content-Type': 'application/json' }, // 设置请求的 header
        success: function (res) {
          console.log(res.data);
          that.setData({
            data: res.data
          })
        }
      })
      wx.showToast({
        title: 'loading...',
        icon: 'loading'
      })
      console.log('onPullDownRefresh', new Date())
    },
    showInput: function () {
      this.setData({
        inputShowed: true
      });
    },
    hideInput: function () {
      this.setData({
        inputVal: "",
        inputShowed: false
      });
    },
    clearInput: function () {
      this.setData({
        inputVal: "",
      });
    },
    inputTyping: function (e) {
      this.setData({
        inputVal: e.detail.value
      });
      wx.showModal({
        title: "友情提示",
        content: "抱歉，此功能暂未开放，为您带来的麻烦深感抱歉！",
        showCancel: false,
        confirmText: "确定"
      })
    },
    onLoad: function (options) {
      var that = this
      wx.request({
        url: 'https://www.iwbagm.cn/xcx/list.php',
        data: {},
        method: 'GET', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
        header: { 'Content-Type': 'application/json' }, // 设置请求的 header
        success: function (res) {
          console.log(res.data);
          that.setData({
           data: res.data
          })
        }
      })
    },
    onShow: function () {
      var that = this
      wx.request({
        url: 'https://www.iwbagm.cn/xcx/list.php',
        data: {},
        method: 'GET', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
        header: { 'Content-Type': 'application/json' }, // 设置请求的 header
        success: function (res) {
          console.log(res.data);
          that.setData({
            data: res.data
          })
        }
      })
    },
    
    gopage(e) {
      console.log(e.currentTarget.dataset.item)
      wx.navigateTo({
        url: '../pay/pay?id=' + e.currentTarget.dataset.item.id + '&lname=' + e.currentTarget.dataset.item.lname + '&lprice=' + e.currentTarget.dataset.item.lprice + '&lcontent=' + e.currentTarget.dataset.item.lcontent + '&state=' + e.currentTarget.dataset.item.state
      })
    },
})
