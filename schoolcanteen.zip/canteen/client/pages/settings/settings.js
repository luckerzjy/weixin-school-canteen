// pages/settings/settings.js
var qcloud = require('../../vendor/wafer2-client-sdk/index')
var config = require('../../config')
var util = require('../../utils/util.js')
var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    focus: false,
    inputValue: '',
    multiArray: [['竹园', '海棠', '丁香'], ['1楼', '2楼', '3楼'], ['1号', '2号', '3号', '4号', '5号', '6号', '7号', '8号', '9号', '10号', '11号', '12号', '13号', '14号', '15号', '16号', '17号', '18号', '19号', '20号', '21号', '22号', '23号', '24号', '25号']],
    multiIndex: [0, 0, 0],
    userInfo: {},
    logged: false,
    takeSession: false,
    requestResult: '',
    sname: '大碗饭',
    sstyle: '口味清淡，辣度适中',
    sdesc: '本店铺售卖家常菜，正如店铺名所说，我们的饭，分量大，又实惠。正是学生平常在家吃的饭菜。健康美味，饭菜可口',
    sdest: '',
    flag: false,
    code: '',
    //canIUse: wx.canIUse('button.open-type.getUserInfo')
  },
  // 用户登录示例
  login: function () {
    util.showBusy('正在登录')
    var that = this
    // 调用登录接口
    wx.login({
      success(result) {
        code: result.code
        wx.request({
          url: "https://www.iwbagm.cn/xcx/login.php/",
          login: true,
          data: { code: result.code},
          success(result) {
            console.log(result.data.openid)
            app.openid = result.data.openid
            that.setData({
            //   userInfo: result.data.data,
              logged: true
              })
            wx.getSetting({
              success: function (res) {
                if (res.authSetting['scope.userInfo']) {
                  // 已经授权，可以直接调用 getUserInfo 获取头像昵称
                  wx.getUserInfo({
                    success: function (res) {
                      util.showSuccess('登录成功')
                      that.setData({
                        userInfo: res.userInfo,
                        logged: true,
                      })
                    }
                  })
                }
              },
            })
          },
          fail(error) {
              util.showModel('请求失败', error)
              console.log('request fail', error)
            }
          })
        },
      fail(error) {
        util.showModel('登录失败', error)
        console.log('登录失败', error)
      },
    
    })
    
  },
  bindGetUserInfo: function (e) {
    console.log(e.detail.userInfo)
  },
  bindMultiPickerChange: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      multiIndex: e.detail.value
    })
  },

  bindMultiPickerColumnChange: function (e) {
    console.log('修改的列为', e.detail.column, '，值为', e.detail.value);
    var data = {
      multiArray: this.data.multiArray,
      multiIndex: this.data.multiIndex,
      flag: false
    };
    data.multiIndex[e.detail.column] = e.detail.value;
    switch (e.detail.column) {
      case 0:
        switch (data.multiIndex[0]) {
          case 0:
            data.multiArray[1] = ['1楼', '2楼', '3楼'];
            data.multiArray[2] = ['01号', '02号', '03号', '04号', '05号', '06号', '07号', '08号', '09号', '10号', '11号', '12号', '13号', '14号', '15号', '16号', '17号', '18号', '19号', '20号', '21号', '22号', '23号', '24号', '25号'];
            break;
          case 1:
            data.multiArray[1] = ['1楼', '2楼'];
            data.multiArray[2] = ['01号', '02号', '03号', '04号', '05号', '06号', '07号', '08号', '09号', '10号', '11号', '12号', '13号', '14号', '15号', '16号', '17号', '18号', '19号', '20号', '21号', '22号', '23号', '24号', '25号'];
            break;
          case 2:
            data.multiArray[1] = ['1楼', '2楼'];
            data.multiArray[2] = ['1号', '2号', '3号', '4号', '5号', '6号', '7号', '8号', '9号', '10号', '11号', '12号', '13号', '14号', '15号', '16号', '17号', '18号', '19号', '20号', '21号', '22号', '23号', '24号', '25号'];
            break;
        }
        data.multiIndex[1] = 0;
        data.multiIndex[2] = 0;
        break;
      case 1:
        switch (data.multiIndex[1]) {
          case 0:
            data.multiArray[2] = ['01号', '02号', '03号', '04号', '05号', '06号', '07号', '08号', '09号', '10号', '11号', '12号', '13号', '14号', '15号', '16号', '17号', '18号', '19号', '20号', '21号', '22号', '23号', '24号', '25号'];
            break;
          case 1:
            data.multiArray[2] = ['01号', '02号', '03号', '04号', '05号', '06号', '07号', '08号', '09号', '10号', '11号', '12号', '13号', '14号', '15号', '16号', '17号', '18号', '19号', '20号', '21号', '22号', '23号', '24号', '25号'];
            break;
          case 2:
            data.multiArray[2] = ['1号', '2号', '3号', '4号', '5号', '6号', '7号', '8号', '9号', '10号', '11号', '12号', '13号', '14号', '15号', '16号', '17号', '18号', '19号', '20号', '21号', '22号', '23号', '24号', '25号'];
            break;
        }
        data.multiIndex[2] = 0;
        break;
    }
    this.setData(data);
  },
  
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
   
    var that = this
    wx.request({
      url: 'https://www.iwbagm.cn/xcx/seller.php/',
      data: { },
      method: 'GET', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
      header: { 'Content-Type': 'application/json' }, // 设置请求的 header
      success: function (res) {
        console.log(res.data['sdest'][4]);
        that.setData({
          sname: res.data['sname'],
          sstyle: res.data['sstyle'],
          sdesc: res.data['sdesc'],
          sdest: res.data['sdest'],
          flag: true
        })         
      }
    }),
      wx.getStorage({
        key: 'image',
        success: function (res) {
          console.log(res.data)
        }
      })
  },

  formSubmit: function (e) {
    var that = this
    console.log('form发生了submit事件，携带数据为', e.detail.value)
    var dest = this.data.multiArray[0][e.detail.value.sdest[0]] + this.data.multiArray[1][e.detail.value.sdest[1]] + this.data.multiArray[2][e.detail.value.sdest[2]];
    if (e.detail.value.sname !== "") {
      var tmpname = e.detail.value.sname;
    } else {
      tmpname = that.data.sname;
    }
    if (e.detail.value.sstyle !== "") {
      var tmpstyle = e.detail.value.sstyle;
    } else {
      tmpstyle = that.data.sstyle;
    }
    if (e.detail.value.sdesc !== "") {
      var tmpdesc = e.detail.value.sdesc;
    } else {
      tmpdesc = that.data.sdesc;
    }
    wx.request({
      url: 'https://www.iwbagm.cn/xcx/update.php',
      data: {
        sname: tmpname,
        sstyle: tmpstyle,
        sdesc: tmpdesc,
        sdest: dest,
      },
      method: 'GET', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
      header: { 'Content-Type': 'application/json' }, // 设置请求的 header
      success: function (res) {
        console.log(res.data)
        util.showSuccess('修改成功')
      }
    })

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})