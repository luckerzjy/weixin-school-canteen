
Page({
  data: {
  de:[
    {
      id:"001",
      shopname:"大碗饭",
      shopstyle:"口味清淡，辣度适中",
      shopintro: "这是一家特别好吃的店",
      shoppic:"/public/images/big.jpg"
    },
    {
      id: "002",
      shoppic: "/public/images/lp.jpg",
      shopstyle: "浓汁厚酱 清爽可口",
      shopname: "魏家凉皮",
      shopintro: "凉皮，饺子，面条有售"
    },
    {
      id: "003",
      shoppic: "/public/images/3.jpg",
      shopstyle: "鲜美可口，原汁原味",
      shopname: "黄焖鸡米饭",
      shopintro: "主打黄焖鸡米饭，另有 各类盒饭"
    },
    {
      id: "004",
      shoppic: "/public/images/s.jpg",
      shopstyle: "醇厚鲜美，辣度适中",
      shopname: "少掌柜",
      shopintro: "各类小炒，可自行选配食材"
    },
    {
      id: "005",
      shoppic: "/public/images/w.jpg",
      shopstyle: "口味清淡，辣度适中",
      shopname: "真味坊",
      shopintro: "口味清淡，各类蒸的食品"
    },
    {
      id: "006",
      shoppic: "/public/images/r.jpg",
      shopstyle: "浓汁赤酱，多种口味",
      shopname: "北海道",
      shopintro: "主打各类日式菜品"
    },
    {
      id: "007",
      shoppic: "/public/images/l.jpg",
      shopname: "邻家美食",
      shopstyle: "口味清淡，辣度适中",
      shopintro: "妈妈的味道，家常炒菜"
    },
    {
      id: "008",
      shoppic: "/public/images/j.jpg",
      shopname: "金牌小菜",
      shopstyle: "香脆可口，味道鲜美",
      shopintro: "主打各类小菜"
    },
    {
      id: "009",
      shoppic: "/public/images/c.jpg",
      shopname: "川乐",
      shopstyle: "辣味十足，有滋有味",
      shopintro: "主打四川口味饭菜"
    },
  ],
  all: [
    {
      id: "1",
      dpic: "/public/images/1.jpg",
      dname: "牛排套餐",
      dprice: "35.00",
      dstyle: ''
    },
    {
      id: "2",
      dpic: "/public/images/2.jpg",
      dname: "水果沙拉",
      dprice: "10.00"
    },
    {
      id: "3",
      dpic: "/public/images/3.jpg",
      dname: "黄焖鸡米饭",
      dprice: "15.00"
    },
    {
      id: "4",
      dpic: "/public/images/4.jpg",
      dname: "意大利面",
      dprice: "12.00"
    },
    {
      id: "5",
      dpic: "/public/images/big.jpg",
      dname: "日式照烧饭",
      dprice: "13.00"
    },
 ],
goodslist: [],
shopname:'黄焖鸡米饭',
shopstyle: '醇厚持久，原滋原味',
shopintro:'这是一家特别好吃的店',
shoppic:'/public/images/1.jpg',
cnt: 0,
isFold: '',
detail: '',
},

select: function (e) {
  this.setData({
    index: e.detail.value
  })
},

onLoad:function(){
    var that = this
    that.setData({
      isFold: true,
      detail: '展开店铺详情'
    });
    wx.getStorage({
      key: 'cout',
      success: function (res) {
        console.log("resdata:" + res.data),
          that.setData({
            cnt: res.data,
          });

      },
    });
    wx.request({
      url: 'https://www.iwbagm.cn/xcx/seller.php/',
      data: {},
      method: 'GET', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
      header: { 'Content-Type': 'application/json' }, // 设置请求的 header
      success: function (res) {
        console.log(res.data)
        that.setData({
          'de[0].shopname': res.data['sname'],
          'de[0].shopstyle': res.data['sstyle'],
          'de[0].shopintro': res.data['sdesc'],
        })
        console.log(that.data.de)
        wx.getStorage({
          key: 'nowid',
          success: function (res) {
            console.log(res.data)
            var k = 0
            if (res.data == '001') {
              k = 0

            }else if (res.data == '002'){
              k = 1
            }
            else if (res.data == '003') {
              k = 2
            }
            else if (res.data == '004') {
              k = 3
            }
            else if (res.data == '005') {
              k = 4
            }
            else if (res.data == '006') {
              k = 5
            }
            else if (res.data == '007') {
              k = 6
            }
            else if (res.data == '008') {
              k = 7
            }
            else if (res.data == '009') {
              k = 8
            }
            console.log(that.data.cnt)

            that.setData({
              shopname: that.data.de[k].shopname,
              shopintro: that.data.de[k].shopintro,
              shopstyle: that.data.de[k].shopstyle,
              shoppic: that.data.de[k].shoppic
            })
            if (res.data == '001') {
              wx.request({
                url: 'https://www.iwbagm.cn/xcx/dish.php',
                data: {},
                method: 'GET', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
                header: { 'Content-Type': 'application/json' }, // 设置请求的 header
                success: function (res) {
                  console.log(res.data);
                  var len = res.data.length
                  that.setData({
                    all: res.data
                  })
                  for (var i = 0; i < len; i++) {
                    var id = 'goodslist[' + i + '].id'
                    console.log(id)
                    var name = 'goodslist[' + i + '].name'
                    var imgUrl = 'goodslist[' + i + '].imgUrl'
                    var price = 'goodslist[' + i + '].price'
                    that.setData({
                      [id]: that.data.all[i].id,
                      [imgUrl]: '/public/images/' + that.data.all[i].dpic,
                      [name]: that.data.all[i].dname,
                      [price]: that.data.all[i].dprice,
                    })
                  }
                }
              })
            } else {
              for (var i = 0; i < 5; i++) {
                var id = 'goodslist[' + i + '].id'
                console.log(id)
                var name = 'goodslist[' + i + '].name'
                var imgUrl = 'goodslist[' + i + '].imgUrl'
                var price = 'goodslist[' + i + '].price'
                that.setData({
                  [id]: that.data.all[i].id,
                  [imgUrl]: that.data.all[i].dpic,
                  [name]: that.data.all[i].dname,
                  [price]: that.data.all[i].dprice,
                })
              }
            }
          }
        })
      }
    })
    
    
},
  flodFn: function () {
    this.setData({
      isFold: !this.data.isFold,

    });
    if (this.data.isFold) {
      this.setData({

        detail: '展开店铺详情'
      });
    }
    else {
      this.setData({

        detail: '收起店铺详情'
      });
    }
  }, 

  toBuy: function () {
    var that = this
    var total = 0
    var arr = wx.getStorageSync('cart') || [];
    console.log(arr);
    var name = arr[0].name + '等';
    var content = '';
    var len = arr.length;
    for (var i = 0; i < len; i++) {
      total += Number(arr[i].price) * Number(arr[i].count);
      content += arr[i].name + '*' + arr[i].count + ' ';
    }
    wx.setStorage({
      key: "money",
      data: total,
    })
    console.log(total);
    wx.getStorage({
      key: 'choice',
      success: function (res) {
        console.log(res.data)
        if (that.data.cnt != 0) {
          if (res.data == 'in') {
            wx.request({
              url: 'https://www.iwbagm.cn/xcx/uploadlist.php',
              data: {
                lname: name,
                lprice: total,
                lcontent: content,
                state: 0,
              },
              method: 'GET', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
              header: { 'Content-Type': 'application/json' }, // 设置请求的 header
              success: function (res) {
                console.log(res.data)
                wx.navigateTo({
                  url: '../count/count'
                })
              }
            })
          }
          else {
            wx.navigateTo({
              url: '../paying/paying'
            })
          }
        }
        else {
          wx.showModal({
            title: "友情提示",
            content: "您还没有点菜哦，购物车空空如也！",
            showCancel: false,
            confirmText: "确定"
          })
        }
      }
    })
  }, 
  tocar: function () {
    wx.navigateTo({
      url: '../car/car'
    })
  }, 



  // 加入购物车  
  addcart: function (e) {
    var _this=this
    wx.getStorage({
      key: 'cout',
      success(res) {
        console.log(res.data)
        _this.setData({
          cnt: res.data+1,
        })
        wx.setStorage({
          key: "cout",
          data: _this.data.cnt
        })
      }
    })

    this.setData({
      toastHidden: false,
      //cnt:a
    });
    // 遍历列表 与 购物车列表  
    for (var i in this.data.goodslist) {       
      // 列表中某一项item的id == 点击事件传递过来的id。则是被点击的项  
      if (this.data.goodslist[i].id == e.target.id) {
        // 给goodsList数组的当前项添加count元素，值为1，用于记录添加到购物车的数量  
        this.data.goodslist[i].count = 1;
        // 获取购物车的缓存数组（没有数据，则赋予一个空数组）  
        var arr = wx.getStorageSync('cart') || [];
        // 如果购物车有数据  
        if (arr.length > 0) {
          // 遍历购物车数组  
          for (var j in arr) {
            // 判断购物车内的item的id，和事件传递过来的id，是否相等  
            if (arr[j].id == e.target.id) {
              // 相等的话，给count+1（即再次添加入购物车，数量+1）  
              arr[j].count = arr[j].count + 1;
              // 最后，把购物车数据，存放入缓存（此处不用再给购物车数组push元素进去，因为这个是购物车有的，直接更新当前数组即可）  
              try {
                wx.setStorageSync('cart', arr)
              } catch (e) {
                console.log(e)
              }
              // 返回（在if内使用return，跳出循环节约运算，节约性能）  
              return;
            }
          }
          // 遍历完购物车后，没有对应的item项，把goodslist的当前项放入购物车数组  
          arr.push(this.data.goodslist[i]);
        }
        // 购物车没有数据，把item项push放入当前数据（第一次存放时）  
        else {
          arr.push(this.data.goodslist[i]);
        }
        // 最后，把购物车数据，存放入缓存  
        try {
          wx.setStorageSync('cart', arr)
          // 返回（在if内使用return，跳出循环节约运算，节约性能）  
          return;
        } catch (e) {
          console.log(e)
        }
      }
    }
  }
})  

