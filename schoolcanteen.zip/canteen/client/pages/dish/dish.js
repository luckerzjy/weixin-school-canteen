// pages/dish/dish.js
var util = require('../../utils/util.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
      data: [
      {
        "id": 1,
        "dpic": "1.jpg",
        "dname": "牛排套餐",
        "dprice": "30.00",
        "dstyle": ''
      },
      {
        "id": 2,
        "dpic": "2.jpg",
        "dname": "水果沙拉",
        "dprice": "10.00",
        "dstyle": ''
      },
      {
        "id": 3,
        "dpic": "3.jpg",
        "dname": "黄焖鸡米饭",
        "dprice": "15.00",
        "dstyle": ''
      },
      {
        "id": 4,
        "dpic": "4.jpg",
        "dname": "意大利面",
        "dprice": "12.00",
        "dstyle": ''
      },
      {
        "id": 5,
        "dpic": "5.jpg",
        "dname": "巨无霸汉堡",
        "dprice": "13.50",
        "dstyle": ''
      }
    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    wx.request({
      url: 'https://www.iwbagm.cn/xcx/dish.php',
      data: {},
      method: 'GET', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
      header: { 'Content-Type': 'application/json' }, // 设置请求的 header
      success: function (res) {
        console.log(res.data);
        that.setData({
          data: res.data
        })
      }
    })
  },
 
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this
    wx.request({
      url: 'https://www.iwbagm.cn/xcx/dish.php',
      data: {},
      method: 'GET', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
      header: { 'Content-Type': 'application/json' }, // 设置请求的 header
      success: function (res) {
        console.log(res.data);0
        that.setData({
          data: res.data
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})